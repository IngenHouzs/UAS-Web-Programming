


<?php $__env->startSection('create-loan'); ?>

        <form action="<?php echo e(route('addLoan')); ?>" method="POST" id="add-loan">
            <?php echo csrf_field(); ?>
         
        Cari NIS atau Nama Siswa
            <input type="text" id="ls-findstudent" name="nama" value="">
            <button type="button" onclick="ls_findStudent()">Cari</button><br/>
            <div class="find-student-notif">
                <h1></h1> <!-- Ini template wrapper kalo ga nemu pelajar (cek liveSearch.js) -->
                <div class="dropdown-ls-student flex flex-column h-auto w-4"> <!-- Ini template buat daftar pelajar kl ketemu -->
                </div>
            </div>
    
    
            Cari Judul Buku
    
            <input type="text" id="ls-findbook" name="book" value="">
            <button type="button" onclick="ls_findBook()">Cari</button><br/>        
            <div class="find-book-notif">
                <h1></h1> <!-- Ini template kalo ga nemu buku -->
                        <!-- Ini template wrapper buat daftar buku kl ketemu -->
                <div class="dropdown-ls-book flex flex-column h-auto w-4"> <!-- Ini template buat daftar pelajar kl ketemu -->
                </div>            
            </div>     
    
            <button type="submit">Tambah</button>              
        </form>       

      
        



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="/js/liveSearch.js"></script>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/create-loan.blade.php ENDPATH**/ ?>