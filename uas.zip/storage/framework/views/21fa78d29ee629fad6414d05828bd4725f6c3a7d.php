


<?php $__env->startSection('edit-book'); ?>


<div class="container my-4 flex flex-column">
    <div class="px-3 bg-white flex flex-column align-items-start add-book-form-wrapper" style="height:auto;">
        <h1>Edit Buku</h1>
        <p><i><?php echo e($book->judul); ?></i></p>
    </div>    
    <div class="px-3 py-1 bg-white flex flex-column align-items-center add-book-form-wrapper shadow">

        <form action="/editbuku/<?php echo e($book->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <p>Rak</p>
            <input type="text" name="no_rak" value="<?php echo e($book->no_rak); ?>" required></input>        
            <br>

            <p>Keterangan</p>
            <input type="text" name="keterangan" value="<?php echo e($book->keterangan); ?>"></input>       
            <br>

            <p>Stok</p>
            <input type="number" name="stok" value="<?php echo e($book->stok); ?>" min="<?php echo e(count($loans)); ?>"></input>              
    
            <button type="submit" class="bg-success text-white rounded px-3">Simpan Perubahan</button>
            
    
        </form>
                
    </div>                   
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/edit-book.blade.php ENDPATH**/ ?>