<?php $__env->startSection('my-loan'); ?>
    <div id="catalogue-list-container" class="container py-3 my-5">
        <div class="row">
            <div class="col">
                <?php if(count($loans) > 0): ?>
                    <h4><b>Daftar Pinjamanku</b></h4>                
                <?php else: ?> 
                    <h4><b>Belum ada pinjaman.</b></h4>                          
                <?php endif; ?> 
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 my-2">
                    <div class="card h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 id="book-title" class="card-title"><?php echo e($loan->judul); ?></h5>
                            <?php if($loan->tanggal_peminjaman && $loan->tenggat_pengembalian): ?>
                                <h6  id="book-details" class="card-subtitle my-2 text-muted">
                                    Tanggal Peminjaman <?php echo e($loan->tanggal_peminjaman); ?> </h6>
                                <h6  id="book-details" class="card-subtitle my-2 text-muted">
                                    Tenggat Pengembalian <?php echo e($loan->tenggat_pengembalian); ?>

                                </h6>
                                <button class="btn btn-warning">
                                    <a href="/collection/<?php echo e($loan->id_buku); ?>">Lihat detail buku</a>
                                </button>
                            <?php else: ?>
                                <small class="mb-2">Requested</small>
                                <div class="d-flex">
                                    <button class="btn btn-warning mr-2">
                                        <a href="/collection/<?php echo e($loan->id_buku); ?>">Lihat detail buku</a>
                                    </button>
                                    <form action="/deleteLoanRequest/<?php echo e($loan->id_peminjaman); ?>" method="POST" class="mt-auto">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-danger ">Batalkan Permintaan</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<!-- 
    <h1>Daftar Pinjamanku</h1>

    <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        Judul : <p><?php echo e($loan->judul); ?></p> 
        <a href="/collection/<?php echo e($loan->id_buku); ?>"><button>Lihat detail buku</button></a>
        <?php if($loan->tanggal_peminjaman && $loan->tenggat_pengembalian): ?>
            Tanggal Peminjaman : <p><?php echo e($loan->tanggal_peminjaman); ?></p> 
            Tenggat Pengembalian : <p><?php echo e($loan->tenggat_pengembalian); ?></p> 
        <?php else: ?> 
            Requested
            <form action="/deleteLoanRequest/<?php echo e($loan->id_peminjaman); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <button type="submit">Batalkan Permintaan</button>
            </form>
        <?php endif; ?>
        <br>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/my-loan.blade.php ENDPATH**/ ?>