<nav id="navbar" class="navbar navbar-expand-md px-3 fixed-top">
    <img class="img-navbar-footer" src="/asset/tunas-mulia-logo.png"/>
    <a href="\" id="navbar-school-name">
        Tunas Mulia Montessori School <br>
        Online Library
    </a>
    <button class="navbar-toggler-icon" data-bs-toggle="collapse" data-bs-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <?php echo $__env->make('components.hamburg-toggler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </button>
    <div class="collapse navbar-collapse justify-content-between" id="navbarsExample04">
        <div id="navbar-menu" class="navbar-nav">
            


            <?php if(auth()->guard()->check()): ?>            
            <?php if(auth()->user()->role === 1): ?>            
                <li class="nav-item">
                    <a href="<?php echo e(route('showAllLoans')); ?>" class="navbar-link nav-link">Data Pinjaman</a>     
                </li>    
                <li class="nav-item">
                    <a href="<?php echo e(route('showPendingRequests')); ?>" class="navbar-link nav-link">Pending</a>     
                </li>                    
                <li class="nav-item">
                    <a href="<?php echo e(route('collection')); ?>" class="navbar-link nav-link">Monitor Katalog</a>     
                </li>  
                <li class="nav-item">
                    <a href="<?php echo e(route('viewAllStudent')); ?>" class="navbar-link nav-link">Data Pelajar</a>     
                </li>                                                       
            <?php elseif(auth()->user()->role === 2): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('home')); ?>" class="navbar-link nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('about')); ?>" class="navbar-link nav-link">Panduan</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('collection')); ?>" class="navbar-link nav-link">Collection</a>     
                </li>          
                <li class="nav-item">
                    <a href="<?php echo e(route('pinjamanku')); ?>" class="navbar-link nav-link">Pinjamanku</a>     
                </li>                    
            <?php endif; ?>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?> 
                <li class="nav-item">
                    <a href="<?php echo e(route('home')); ?>" class="navbar-link nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('about')); ?>" class="navbar-link nav-link">Panduan</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('collection')); ?>" class="navbar-link nav-link">Collection</a>     
                </li>               
            <?php endif; ?> 
        </div>

        <div class="navbar-nav" id="navbar-user-status">
            <?php if(auth()->guard()->check()): ?> 
                <?php if(auth()->user()->role === 2): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('forgetPasswordView')); ?>" class="navbar-link nav-link">Ganti Kata Sandi</a>     
                    </li>                      
                <?php endif; ?> 
            <?php endif; ?> 

            <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();','class' => 'log-in-out nav-item nav-link']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();','class' => 'log-in-out nav-item nav-link']); ?>
                                <?php echo e(__('Log Out')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </form>

                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="log-in-out nav-item nav-link" >Log in</a>
                    <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/partials/navbar.blade.php ENDPATH**/ ?>