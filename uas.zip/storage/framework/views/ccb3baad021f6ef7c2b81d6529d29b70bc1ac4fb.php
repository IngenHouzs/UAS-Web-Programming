<?php $__env->startSection('view-book'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col">
            <?php if(session('SELF_QUOTA_FULL')): ?>
                <p><?php echo e(session('SELF_QUOTA_FULL')); ?></p>
            <?php endif; ?>
            
            <?php if(session('DOUBLE_REQUEST')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('DOUBLE_REQUEST')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('EDIT_SUCCESS')): ?>
                <div class="alert alert-success" role="alert">            
                    <?php echo e(session('EDIT_SUCCESS')); ?>

                </div>                
            <?php endif; ?>            

            <?php if(session('LOAN_SUCCESS')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('LOAN_SUCCESS')); ?>

                </div>
            <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="container my-3">
        <div class="row">
            <div class="col">
                <button type="submit" class="btn btn-warning"><a href="/collection">Kembali</a></button>   
            </div>
        </div>
        <div id="book-details-container" class="row my-2">
            <div class="col">
                <div class="jumbotron">
                    <h1 class="display-4"><?php echo e($book->judul); ?></h1>
                    <hr class="my-4 hr-book">
                    <table id="book-details-table">
                        <tr>
                            <td>Karya</td>
                            <td>:</td>
                            <td>
                            <?php $__currentLoopData = $book->author; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($author->nama_penulis); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </td>
                        </tr>
                        <tr>
                            <td>Penerbit</td>
                            <td>:</td>
                            <td><?php echo e($book->publisher->nama_penerbit); ?></td>
                        </tr>
                        <tr>
                            <td>Tahun Terbit</td>
                            <td>:</td>
                            <td><?php echo e($book->tahun_terbit); ?></td>
                        </tr>  
                        <tr>
                            <td>Tempat Terbit</td>
                            <td>:</td>
                            <td><?php echo e($book->tempat_terbit); ?></td>
                        </tr>                          
                        <tr>
                            <td>Halaman</td>
                            <td>:</td>
                            <td><?php echo e($book->halaman); ?></td>
                        </tr>                   
                        <tr>
                            <td>DDC</td>
                            <td>:</td>
                            <td><?php echo e($book->ddc); ?></td>
                        </tr>                      
                        <tr>
                            <td>ISBN</td>
                            <td>:</td>
                            <td><?php echo e($book->isbn); ?></td>
                        </tr>                       
                        <tr>
                            <td>No Rak</td>
                            <td>:</td>
                            <td><?php echo e($book->no_rak); ?></td>
                        </tr>                                        
                        <tr>
                            <td>Stok</td>
                            <td>:</td>
                            <td><?php echo e($book->stok); ?></td>
                        </tr>
                        <tr>
                            <td>Keterangan</td>
                            <td>:</td>
                            <td><?php echo e($book->keterangan); ?></td>
                        </tr>                          
                       
                    </table>
                    <hr class="my-4 hr-book">
                    <table  id="book-status-table" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Terpinjam</td>
                                <?php if($loan->tenggat_pengembalian): ?>
                                    <td>Sedang dipakai (Tenggat pengembalian : <?php echo e($loan->tenggat_pengembalian); ?> )</td>
                                <?php else: ?>
                                    <td>Dipesan</td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php for($ctr = 0; $ctr < $book->stok; $ctr++): ?>
                            <tr>
                                <td>Tersedia</td>
                                <td>-</td>
                            </tr>
                        <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row mb-5">
            <div class="col">
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role == 2): ?>
                    <form action="<?php echo e(route('requestLoan', [$book->id, auth()->user()->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(count($loans) >= $defaultStock): ?>
                            <button type="submit" disabled style="btn btn-danger">Ajukan Peminjaman</button>   
                        <?php else: ?>
                            <button type="submit" class="btn btn-success">Ajukan Peminjaman</button>
                        <?php endif; ?>
                    </form>   
                <?php else: ?> 
                    <div class="flex flex-row">
                        <form action="/deleteBook/<?php echo e($book->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="bg-danger text-white px-3 rounded" type="submit">Hapus Buku</button>                           
                        </form>
                        <a href="/editbuku/<?php echo e($book->id); ?>"><button class="bg-primary text-white px-2 rounded mx-3">Edit Buku</button></a>
                    </div>
                <?php endif; ?> 
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <form action="<?php echo e(route('requestLoan', [$book->id, $book->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(count($loans) >= $defaultStock): ?>
                        <button type="submit" disabled style="btn btn-danger">Ajukan Peminjaman</button>            
                    <?php else: ?>
                        <button type="submit" class="btn btn-success">Ajukan Peminjaman</button>
                    <?php endif; ?>
                </form>       
            <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/view-book.blade.php ENDPATH**/ ?>