<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>