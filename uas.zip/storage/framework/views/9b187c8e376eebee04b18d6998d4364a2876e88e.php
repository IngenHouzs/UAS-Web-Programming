

<?php $__env->startSection('forget-password'); ?>

    <div class="container my-4 flex flex-column">
        <div class="px-3 bg-warning flex flex-row align-items-center daftar-siswa-header shadow">
            <h1 class="h4">Ganti Kata Sandi</h1>
        </div>
        <div class="bg-white daftar-desc px-3 py-2 shadow">
            <form action="/forgetpassword" method="POST">
                <?php echo csrf_field(); ?>
                <p>Kata sandi</p>
                <input type="password" name="password"  required>
                <p>Konfirmasi kata sandi</p>
                <input type="password" name="confirm_password" required>        
        
                <button class="bg-warning rounded px-3 change-pw-button" type="submit">Ganti Kata Sandi</button>
        
            </form>
        
        </div>
    </div>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/forget-password.blade.php ENDPATH**/ ?>