

<?php $__env->startSection('pending'); ?>


    <?php if(session('REQUEST_ACCEPTED')): ?>
        <h1><?php echo e(session('REQUEST_ACCEPTED')); ?></h1>
    <?php endif; ?>

    <div class="container my-4 px-3 pt-2 pb-3 flex flex-column pending-wrapper">
        <div class="daftar-pinjaman-header w-full">
            <h1>Daftar Permintaan Pending</h1>
        </div>        
        <div class="flex flex-row justify-content-center pending-search-siswa bg-white">
            <div class="half-color-parts"></div>
            <form action="/pending" method="GET">
                <input type="text" placeholder="Masukkan Nama Siswa" name="nama"></input>
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>  
        </div>
        <div class="pinjaman-pending-body bg-white">

            <?php if(count($requests) > 0): ?>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white shadow flex flex-column pending-card">
                        <h1 class="h3"><?php echo e($request->nama); ?></h1>
                        <p class="text-muted"><?php echo e($request->nis); ?></p>
                        <a href="/collection/<?php echo e($request->book_id); ?>" class="text-primary h5"><?php echo e($request->judul); ?></a>                               

                        <div class="flex flex-row justify-content-start action-button-loanlist">
                            <form action="<?php echo e(route('acceptLoan', [$request->id_peminjaman, $request->nis, $request->book_id])); ?>" method="POST">   
                                <?php echo csrf_field(); ?>      
                                <button class="mr-2 bg-secondary text-white" type="submit">Terima</button>
                            </form>
                            <form action="<?php echo e(route('rejectLoan', [$request->id_peminjaman])); ?>" method="POST">
                                <?php echo csrf_field(); ?> 
                                <button class="mr-2 bg-success text-white" type="submit">Tolak</button>
                            </form>                        
                        </div>

            
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
            <?php else: ?> 
                <?php if($search): ?> 
                    <p class="text-center font-weight-bold">Data tidak ditemukan.</p>                  
                <?php else: ?> 
                    <p class="text-center font-weight-bold">Belum ada pengajuan pinjaman saat ini.</p>                
                <?php endif; ?>                  
            <?php endif; ?>

    
        </div>
    </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/pending.blade.php ENDPATH**/ ?>