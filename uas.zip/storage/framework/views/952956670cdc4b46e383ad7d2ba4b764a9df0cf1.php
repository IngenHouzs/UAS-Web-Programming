

<?php $__env->startSection('view-student'); ?>

    <div class="container my-4 flex flex-column">
        <div class="w-100 px-3 bg-primary flex flex-row align-items-center profil-siswa-header">
            <h1 class="h4 text-white">Profil Siswa</h1>
        </div>
        <div class="bg-white w-100 px-3 profil-desc">
            <h1>Nama</h1>
            <p><?php echo e($student->name); ?></p>
            <h1>NISN</h1>
            <p><?php echo e($student->nisn); ?></p>
        </div>
    </div>

    <div class="container my-4 flex flex-column">
        <div class="w-100 px-3 bg-primary flex flex-row align-items-center profil-siswa-header">        
            <h1 class="h4 text-white">Daftar Pinjaman</h1>
        </div>
        <div class="bg-white w-100 px-3 py-2 flex flex-column profil-descs">
            
            <?php if(count($loans) > 0): ?> 
                <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-80 h-10 px-4 py-3 <?php if(!$loan->late): ?> bg-white <?php endif; ?> shadow flex flex-column loan-card" style="<?php if($loan->late): ?> background-color:#ffd2cf <?php endif; ?>">
                        <?php if($loan->tanggal_peminjaman && $loan->tenggat_pengembalian): ?>
                            <div class="flex flex-column loan-desc">
                                <h1 style="font-weight:bold">Judul Buku</h1>
                                <a href="/collection/<?php echo e($loan->id_buku); ?>" class="text-primary"><?php echo e($loan->judul); ?></a>
                            </div>
                            <div class="flex flex-column loan-desc">
                                <h1 style="font-weight:bold">Tanggal Peminjaman</h1>
                                <a><?php echo e($loan->tanggal_peminjaman); ?></a>
                            </div>
                            <div class="flex flex-column loan-desc">
                                <h1 style="font-weight:bold">Tenggat Pengembalian</h1>
                                <a><?php echo e($loan->tenggat_pengembalian); ?></a>
                            </div>                                                     
                        <?php else: ?> 
                            <div class="flex flex-column loan-desc">
                                <h1 style="font-weight:bold">Judul Buku</h1>
                                <a href="/collection/<?php echo e($loan->id_buku); ?>" class="text-primary"><?php echo e($loan->judul); ?></a>
                            </div>
                            <form action="/acceptLoan/<?php echo e($loan->id_peminjaman); ?>/<?php echo e($student->nisn); ?>/<?php echo e($loan->id_buku); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="text" hidden name="redirect" value="1">
                                <button type="submit" class="bg-primary text-white px-2 rounded">Terima Peminjaman</button>
                            </form>
                        <?php endif; ?>
                    </div>                 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
            <?php else: ?>
                <p class="text-center font-weight-bold">Tidak ada aktivitas.</p>                
            <?php endif; ?>

    
        </div>        
    </div>    









<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/view-student.blade.php ENDPATH**/ ?>