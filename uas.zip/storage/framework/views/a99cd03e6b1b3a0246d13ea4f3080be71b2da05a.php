


<?php $__env->startSection('loanlist'); ?>




<div class="container my-4 px-3 pt-2 pb-3 flex flex-column">
    <div class="daftar-pinjaman-header w-full bg-warning bg-gradient">
        <h1 class="text-center">Daftar Pinjaman</h1> 
        <div class="flex flex-row justify-content-center daftar-pinjaman-search">
            <form action="/loans" method="GET">
                <input type="text" placeholder="Masukkan Nama Siswa" name="nama"></input>
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>  
        </div>
    </div>

    <div class="daftar-pinjaman-body w-full h-auto bg-light bg-gradient">
     
        <div class="flex flex-row justify-content-between">
            <div onclick="filterDropdown()" class="filter-dropdown bg-primary text-white w-20">
                Filter
                <div class="dropdown-filter" style="display:none;">
                    <a href="/loans?filter=asc"><button>Terlama</button></a>
                    <a href="/loans?filter=desc"><button>Terbaru</button></a>
                    <a href="/loans?filter=late"><button>Terlambat</button></a>                                        
                    <a href="/loans?filter=ongoing"><button>Sedang Berjalan</button></a>                        
                </div>
            </div>    
            
            <form class="mb-3" action="<?php echo e(route('createLoanView')); ?>" method="GET">
                <button class="bg-dark"type="submit">Tambah Pinjaman Baru</button>
            </form>       
        </div>
   


        
        <?php if(count($loans) > 0): ?>

            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-80 h-10 px-4 <?php if(!$loan->late): ?> bg-white <?php endif; ?> shadow flex flex-column loan-card" style="<?php if($loan->late): ?> background-color:#ffd2cf <?php endif; ?>">
                    <div class="w-100 flex flex-row loan-inner-card">
                        <div class="w-50">
                            <h1 class="h3"><?php echo e($loan->nama); ?></h1>
                            <p class="text-muted"><?php echo e($loan->nis); ?></p>
                            <a href="/collection/<?php echo e($loan->id_buku); ?>" class="text-primary h5"><?php echo e($loan->judul); ?></a>
                        </div>
                        <div class="w-50 flex flex-row justify-content-between pt-1 loan-date">
                            <div class="flex flex-column">
                                <h1 class="h5"><strong>Tanggal Peminjaman</strong></h1>
                                <p class="h6"><?php echo e($loan->tanggal_peminjaman); ?></p>
                            </div>
                            <div class="flex flex-column">
                                <h1 class="h5"><strong>Tenggat Pengembalian</strong></h1>
                                <p class="h6"><?php echo e($loan->tenggat_pengembalian); ?></p>
                            </div>
                        </div>                            
                    </div>
                    
                    <div class="flex flex-row justify-content-start action-button-loanlist">
                        <form action="/extendLoan/<?php echo e($loan->id_peminjaman); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="mr-2 bg-secondary text-white" type="submit">Tambah Durasi Pinjaman</button>
                        </form>         
                        <form action="/deleteLoan/<?php echo e($loan->id_peminjaman); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="mr-2 bg-success text-white" type="submit">Buku telah dikembalikan</button>
                        </form>  
                    </div>

                    
                </div>            
    
                <br/>          
                <br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

        <?php else: ?>
                <?php if($search): ?> 
                    <p class="text-center font-weight-bold">Data tidak ditemukan.</p>                  
                <?php else: ?> 
                    <p class="text-center font-weight-bold">Belum ada pinjaman saat ini.</p>                
                <?php endif; ?> 


        <?php endif; ?>

    </div>

 


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/loanlist.blade.php ENDPATH**/ ?>