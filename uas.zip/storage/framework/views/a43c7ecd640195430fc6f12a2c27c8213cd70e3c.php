

<?php $__env->startSection('add-student'); ?>

    <?php if(session('STUDENT_CREATED')): ?>
        <p><?php echo e(session('STUDENT_CREATED')); ?></p>
    <?php endif; ?>

    <div class="container my-4 flex flex-column">
        <div class="px-3 bg-success flex flex-row align-items-center daftar-siswa-header shadow">
            <h1 class="h4 text-white">Daftarkan Siswa</h1>
        </div>
        <div class="bg-white daftar-desc px-3 py-2 shadow">
            <form action="/tambahsiswa" method="POST">
                <?php echo csrf_field(); ?>
                <p>NISN</p>
                <input type="text" name="nisn" required></input>
                <p>Nama Siswa</p>
                <input type="text" name="name" required></input>

                <button class="rounded bg-success text-white px-2" type="submit">Tambahkan</button>
                
            </form>
        
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.with-header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\xampp\laravel\Kuliah\Projek UAS\UAS-Web-Programming-clone\uas\resources\views/add-student.blade.php ENDPATH**/ ?>